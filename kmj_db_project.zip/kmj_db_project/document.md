# oracle DB install guide
https://backendcode.tistory.com/266

# oracle DB create user
https://teck10.tistory.com/384
https://jojelly.tistory.com/54

# oracle SQL Developer connect
https://velog.io/@yeoonnii/Oracle-SQL-Developer-%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%EC%84%A4%EC%B9%98%EC%A0%91%EC%86%8D

# python oracledb user guide
https://oracle.github.io/python-oracledb/samples/tutorial/Python-and-Oracle-Database-The-New-Wave-of-Scripting.html
https://ljhokgo.tistory.com/entry/Python%EC%9C%BC%EB%A1%9C-Oracle-DB-%EC%97%B0%EB%8F%99%ED%95%98%EA%B8%B0

# oracle DB naming conception
https://launchbylunch.com/posts/2014/Feb/16/sql-naming-conventions/

# oracle DB create table
https://gent.tistory.com/322
https://ljhokgo.tistory.com/entry/Python%EC%9C%BC%EB%A1%9C-Oracle-DB-%EC%97%B0%EB%8F%99%ED%95%98%EA%B8%B0
https://stackoverflow.com/questions/11296361/how-to-create-id-with-auto-increment-on-oracle

# oracle DB drop table (delete table)
https://devjhs.tistory.com/432

# oracle DB insert
https://coding-factory.tistory.com/424

# QT designer
https://ggangtalife.tistory.com/26

# Pyside multiple window
https://trading-for-chicken.tistory.com/23

# Pyside window size and location
https://goodgodgd.github.io/ian-flow/archivers/intro-pyqt5
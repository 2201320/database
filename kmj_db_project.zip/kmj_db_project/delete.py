import oracledb
import manage_db

if __name__ == "__main__":
    odb_con = oracledb.connect(user="MINJAE", password="0000", host="localhost", port=1521, service_name="orcl")
    manage_db.drop_table(odb_con)
    odb_con.close()
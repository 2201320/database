create user minjae identified by 0000;
grant connect, resource, dba to minjae;